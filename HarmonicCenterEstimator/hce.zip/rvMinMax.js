inlets = 1
outlets = 1

var array = new Array();
var largest;
var smallest;
var poslargest;
var possmallest;

function list() {
	array = arrayfromargs(messagename,arguments);
	largest = Math.max.apply(Math,array);
	smallest = Math.min.apply(Math,array);
	poslargest = array.indexOf(largest);
	possmallest = array.indexOf(smallest);
	outlet(0, smallest, possmallest, largest, poslargest);
}